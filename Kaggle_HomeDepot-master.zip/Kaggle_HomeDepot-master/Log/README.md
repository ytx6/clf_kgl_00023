This folder contains logs for Chenglong's features and models.
* `feature`: logs of most of the features

* `level1_models`: logs of all the 1st level models used for building 2nd level model (a.k.a. Chenglong's final ensemble)

* `feature_combiner_level2_meta_linear_201605030922_2016-05-03-09-23.log`: log of the features (i.e., 1st level models) chosen for building 2nd level model
 
* `[Feat@level2_meta_linear_201605030922]_[Learner@reg_ensemble]_hyperopt_2016-05-07-18-42.log`: log of the 2nd level model